This firmware is a modified version of the original DC18 firmware that
when a user selects the ninja unlock challenge attempts to brute force the
needed keys using a xorshift PRNG, as opposed to requesting the user input
for the pins. The firmware will keep attempting to find codes until a user 
selects a valid code they want ;-)

The sdm_pROM_xRAM.elf.S file is the compiled firmware to be sent via a Terminal
program as per the DC18 slides. To control the Brute force use the following:

* SW1 will reset the ninja mode to default, unlocked, ready to accept a code.
* SW0 will brute-force a PIN code, when one is found the LED's will turn on.
  (during operation the LEDs on the back will be off.) after a successful code
  is found, the code is output to the display.

* SW1 & SW2 - attempt to validate the firmware with the last found key.

This was coded for fun, just to attempt to get a decent PRNG onto the DC18 badge.
Enjoy!

  -- prdelka
