#!/usr/bin/perl
#NINJA SPACE ALIEN [NSA] BOT
#
#Description: irc bot which logs chatrooms when triggers are made.
#             also supports logging all a users text typed in any
#             chatrooms the bot is in. bot is controlled through 
#             an irc admin channel.
#
# - prdelka
use IO::Socket;

#################
# Configuration # 
#################

my $ircserver = "irc.hackersarehere.net";
my $nickname = "spybot";
my $admin_channel = "#YOURSHITCHANNEL"; 

####DO NOT EDIT BELOW HERE###

my @ircchannels;
my @stalker;
my @triggers;
my @pipes;
my $pipecount = -1;
my $irccount = -1;
my $stalkcount = -1;
my $trigcount = -1;

#############################
# connect to the IRC server #
# and join admin channel    #
#############################

$sock = IO::Socket::INET->new(
 PeerAddr => $ircserver,
 PeerPort => 6667, 
 Proto => 'tcp' ) or die "could not make the connection";
 
while($line = <$sock>){
 if($line =~ /(NOTICE AUTH).*(checking ident)/i){
  print $sock "NICK $nickname\nUSER crack.down 0 0 :crack.down\@sun.down\n";
  last;
 }
}
while($line = <$sock>){
 if($line =~ /^PING/){
  print $sock "PONG :" . (split(/ :/, $line))[1];
 }
 if($line =~ /(376|422)/i){
  #print $sock "NICKSERV :identify nick_password\n";
  last;
 }
}
sleep 3;
print $sock "JOIN $admin_channel nopnop\n";

###################
# START main loop #
###################

while ($line = <$sock>) {
 #$text is the stuff from the ping or the text from the server
 ($command, $text) = split(/ :/, $line);   


################
# PING handler #
################ 

 if ($command eq 'PING'){
  while ( (index($text,"\r") >= 0) || (index($text,"\n") >= 0) ){ chop($text); }
  print $sock "PONG $text\n";
  next;
 }

################
# KICK handler #
################
($kickee, $cmd, $channel,$nick,$reason) = split(/ /, $line);   
if($cmd eq 'KICK'){
	for(my $i = 0;$i <= $stalkcount;$i++){
		if($nick =~ m/$stalker[$i]/gi){
	        open(FILE,">>logfile");
		print FILE "[$channel] $nick was kicked by $kickee with $reason\n";
		close(FILE);	
		}
    	}	
	for(my $loop = 0;$loop <= $irccount;$loop++){
		if($channel eq $ircchannels[$loop]){
			if($nick =~ m/$nickname/g){
				sleep 2;
				print $sock "PRIVMSG $admin_channel :[+] [$channel] $kickee kicked us with $reason\n";
				sleep 2;
				print $sock "JOIN $ircchannels[$loop]\n";
			        open(FILE,">>logfile");
				print FILE "[$channel] $kickee kicked us with $reason\n";		     
			        close(FILE);
				}
		}
	}
}


($nick,$cmd,$channel) = split(/ /,$line);
		chomp($channel);
		$channel =~ s/://;
		if($cmd eq 'JOIN'){
			for(my $i = 0;$i <= $stalkcount;$i++){
				if($nick =~ m/$stalker[$i]/gi){
				        open(FILE,">>logfile");
					print FILE "[$channel] $nick has joined the channel\n";
					close(FILE);	
				}
    			}	
		}
		if($cmd eq 'PART'){
			for(my $i = 0;$i <= $stalkcount;$i++){
				if($nick =~ m/$stalker[$i]/gi){
				        open(FILE,">>logfile");					
					print FILE "[$channel] $nick has left the channel\n";
					close(FILE);	
				}
    			}	
		}
		if($cmd eq 'QUIT'){
			for(my $i = 0;$i <= $stalkcount;$i++){
				if($nick =~ m/$stalker[$i]/gi){
			        open(FILE,">>logfile");
				print FILE "$nick has quit IRC\n";
				close(FILE);	
				}
			}	
		}


################
# CHAN handler #
################

($server, $stat, $nick, $channel, $junk) = split(/ /, $line);   

if($stat =~ m/473/g){
	for(my $loop = 0;$loop <= $irccount;$loop++){
		if($channel eq $ircchannels[$loop]){
		sleep 2;
		print $sock "PRIVMSG $admin_channel :[+] cannot join $channel - invite only\n";
	        open(FILE,">>logfile");
		print FILE "couldnt join $channel - invite only\n";		
	        close(FILE);
		$ircchannels[$loop] = "";
		}
	}
	        for(my $i = 0;$i <= $pipecount;$i++){
		if($channel =~ m/$pipes[$i]/gi){
		sleep 2;
		print $sock "PRIVMSG $admin_channel :[+] cannot pipe $channel - invite only\n";
		$pipes[$i] = "";
		}
	}
}
if($stat =~ m/474/g){
	for(my $loop = 0;$loop <= $irccount;$loop++){
		if($channel eq $ircchannels[$loop]){
		sleep 2;
		print $sock "PRIVMSG $admin_channel :[+] cannot join $channel - banned\n";
	        open(FILE,">>logfile");
		print FILE "couldnt join $channel - banned\n";		     
	        close(FILE);
		$ircchannels[$loop] = "";
		}
	}
        for(my $i = 0;$i <= $pipecount;$i++){
		if($channel =~ m/$pipes[$i]/gi){
		sleep 2;
		print $sock "PRIVMSG $admin_channel :[+] cannot pipe $channel - banned\n";
		$pipes[$i] = "";
		}
	}
}

if($stat =~ m/475/g){
	for(my $loop = 0;$loop <= $irccount;$loop++){
		if($channel eq $ircchannels[$loop]){
		sleep 2;
		print $sock "PRIVMSG $admin_channel :[+] cannot join $channel - bad key\n";
	        open(FILE,">>logfile");
		print FILE "couldnt join $channel - bad key\n";		     
	        close(FILE);
		$ircchannels[$loop] = "";
		}
	}
	        for(my $i = 0;$i <= $pipecount;$i++){
		if($channel =~ m/$pipes[$i]/gi){
		sleep 2;
		print $sock "PRIVMSG $admin_channel :[+] cannot pipe $channel - bad key\n";
		$pipes[$i] = "";
		}
	}
}


#################
# Main BOT code #
#################

 
 ($nick,$type,$channel) = split(/ /, $line); #split by spaces
 
 ($nick,$hostname) = split(/!/, $nick); #split by ! to get nick and hostname seperate
 
 $nick =~ s/://; #remove :'s
 #$text =~ s/://;
 
 #get rid of all line breaks.  Again, many different way of doing this.
 $/ = "\r\n";
 while($text =~ m#$/$#){ chomp($text); }

    for(my $i = 0;$i <= $pipecount;$i++){
	if($channel =~ m/$pipes[$i]/gi){
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[$channel] <$nick> $text\n";
	}
    }

    for(my $loop = 0;$loop <= $irccount;$loop++){

    if($channel eq $ircchannels[$loop]){

    for(my $i = 0;$i <= $trigcount;$i++){
        if($text =~ m/$triggers[$i]/gi){
        open(FILE,">>logfile");
        print FILE "[$channel] <$nick> $text\n";
        close(FILE);
	$text = "";
        };
    }

    for(my $i = 0;$i <= $stalkcount;$i++){
	if($nick =~ m/$stalker[$i]/gi){
        open(FILE,">>logfile");
	print FILE "[$channel] <$nick> $text\n";
	close(FILE);	
	}
    }

  }
}


######################
# ADMIN CHANNEL CMDS #
######################

if($channel eq $admin_channel){

if($text =~ /!help/){
        ($trigger,$stalk) = split /!stalk /,$text;
	print $sock "PRIVMSG $admin_channel :[+] [NSA] NINJA SPACE ALIEN - bot commands\n";
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[-] !log           - displays the logfile\n";
	sleep 2;	
	print $sock "PRIVMSG $admin_channel :[-] !stalk <NICK>  - log all text by NICK\n";
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[-] !spy #CHAN     - begins monitoring #CHAN\n";
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[-] !trigger TRIG  - adds TRIG to triggers list\n";
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[-] !pipe #CHAN    - transmits #CHAN output\n";
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[-] !clear stalk   - clears the nicknames list\n";
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[-] !clear spy     - clears the channels list\n";
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[-] !clear trigger - clears the triggers list\n";
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[-] !clear pipe    - clears the pipe list\n";
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[-] !clear log     - srm's the logfile\n";
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[-] !stats         - show monitored channels/nicks/triggers list\n";
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[-] !quote RAW     - send RAW command to IRC daemon\n";
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[-] !help          - displays the helpfile\n";
    }


if($text =~ /!log/){
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[+] displaying logfile\n";
	my @logfile;
	open(FILE,"logfile");
	while(<FILE>){
		$logtext = $_;
	}
	close(FILE);
	while($logtext){
	(@logfile,$logtext) = split(/\n/,$logtext);
	};
	$size = @logfile;
	for(my $a = 0;$a <= $size;$a++){
		sleep 2;
		print $sock "PRIVMSG $admin_channel :$logfile[$a]\n";
	}
	
}

if($text =~ /!quote/){
	($trigger,$rawcmd) = split /!quote /,$text;
        sleep 2;
        print $sock "$rawcmd\n";
	sleep 2;
        print $sock "PRIVMSG $admin_channel :[+] sent $rawcmd irc command\n";
}

if($text =~ /!pipe/){
        ($trigger,$piped) = split /!pipe /,$text;
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[+] we are transmitting $piped\n";
	$pipecount = $pipecount + 1;
	$pipes[$pipecount] = "$piped";	
	my $join = 1;
        for(my $i = 0;$i <= $irccount;$i++){
	if($piped =~ m/$ircchannels[$i]/gi){
		$join = 0;
	}
        }
	if($ircchannels eq $admin_channel){$join = 0;}
	if($join == 1){sleep 2;
	print $sock "JOIN $piped\n"
	};    
}

if($text =~ /!stalk/){
        ($trigger,$stalk) = split /!stalk /,$text;
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[+] we are observing entity $stalk\n";
	$stalk =~ tr/[.]/[\\.]/;
	$stalk =~ s/\\/\\\./;
	$stalkcount = $stalkcount + 1;
	$stalker[$stalkcount] = $stalk;
    }

if($text =~ /!spy/){
        ($trigger,$chan) = split /!spy /,$text;
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[+] we are observing $chan\n";
	$irccount = $irccount + 1;
	$ircchannels[$irccount] = "$chan";	
	my $join = 1;
        for(my $i = 0;$i <= $pipecount;$i++){
	if($chan =~ m/$pipes[$i]/gi){
		$join = 0;
	}
        }
	if($ircchannels eq $admin_channel){$join = 0;}
	if($join == 1){
	sleep 2;
	print $sock "JOIN $chan\n"};    
}

if($text =~ /!trigger/){
        ($trigger,$trig) = split /!trigger /,$text;
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[+] listening to the skies for $trig\n";
	$trig =~ tr/[.]/[\\.]/;
	$trig =~ s/\\/\\\./;
	$trigcount = $trigcount + 1;
	$triggers[$trigcount] = $trig;
}

if($text =~ /!clear/){
        ($trigger,$cmd) = split /!clear /,$text;
	if($cmd =~ m/stalk/gi){
		$stalkcount = -1;
		print $sock "PRIVMSG $admin_channel :[+] nicknames list cleared\n";
	}
	if($cmd =~ m/spy/gi){
		for(my $b = 0;$b <= $irccount;$b++){
		sleep 2;
		print $sock "PART $ircchannels[$b]\n";
		if($ircchannels[$b] eq $admin_channel){
		print $sock "JOIN $admin_channel\n";
		}
		}
	        for(my $c = 0;$c <= $pipecount;$c++){ 
		for(my $d = 0;$d <= $irccount;$d++){ 
			if($pipes[$c] =~ m/$ircchannels[$d]/gi){
			sleep 2;
			print $sock "JOIN $ircchannels[$d]\n"; # rejoin all channels that are on pipe list! :)
			}	
		}
        	}
		$irccount = -1;
		sleep 2;
		print $sock "PRIVMSG $admin_channel :[+] channels list cleared\n";
	}
	if($cmd =~ m/trigger/gi){			
		$trigcount = -1;
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[+] triggers list cleared\n";
	}
	if($cmd =~ m/log/gi){			
		system("srm -rf ./logfile &");
	sleep 2;
	print $sock "PRIVMSG $admin_channel :[+] securely wiped the logfile\n";
	}	
	if($cmd =~ m/pipe/gi){
	for(my $a = 0;$a <= $pipecount;$a++){
			sleep 2;			
			print $sock "PART $pipes[$d]\n"; # part all channels in pipe list
			if($pipes[$d] eq $admin_channel){
			print $sock "JOIN $admin_channel\n";
			}
	}
        for(my $c = 0;$c <= $irccount;$c++){ 
		for(my $d = 0;$d <= $pipecount;$d++){ 
			if($ircchannels[$c] =~ m/$pipes[$d]/gi){
			sleep 2;
			print $sock "JOIN $pipes[$d]\n"; # rejoin all channels that are on spy list! :)
			}	
		}
        }
		$pipecount = -1;
		sleep 2;
		print $sock "PRIVMSG $admin_channel :[+] channel pipes cleared\n";
	}
}


if($text =~ /!stats/){
	print $sock "PRIVMSG $admin_channel :[+] we are observing your earth...\n";
	for(my $a = 0;$a <= $stalkcount;$a++){
	if(!$stalker[$a] == ""){
		sleep 2;
		print $sock "PRIVMSG $admin_channel :[NICK] $stalker[$a]\n";
		}
	}
	for(my $b = 0;$b <= $irccount;$b++){
	if(!$ircchannels[$b] == ""){
		sleep 2;
		print $sock "PRIVMSG $admin_channel :[CHAN] $ircchannels[$b]\n";
		}	
	}
	for(my $c = 0;$c <= $trigcount;$c++){
	if(!$triggers[$c] == ""){
		sleep 2;
		print $sock "PRIVMSG $admin_channel :[TRIG] $triggers[$c]\n";
		}	
	}
	for(my $d = 0;$d <= $pipecount;$d++){
	if(!$pipes[$d] == ""){
		sleep 2;
		print $sock "PRIVMSG $admin_channel :[PIPE] $pipes[$d]\n";
		}	
	}
}
}
}