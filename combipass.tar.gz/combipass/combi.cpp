/* PRIVATE!!! PRIVATE!!! PRIVATE!!!
* Takes a username and password file and outputs a COMBI list.
*
* test:test
* test:123
* test:password
*
* for use with programs that need such list types.
*/
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main(int argc,char *argv[]){
	cout << "COMBI password list maker!" << endl;
	if(!argv[1] || !argv[2]){
		cerr << "Error: use with <passfile> <user>" << endl;
		exit(0);
		}
	cout << "Using username: " << argv[2] << endl;
	cout << "Making combi list from password file " << argv[1] << "..." << endl;
	cout << "Saving to ./combi.pass..." << endl;
	string passwd;
	string user = argv[2];
	ifstream passwords (argv[1]);
	ofstream newlist ("./combi.pass");
		while(getline(passwords,passwd)){
			newlist << user << ":" << passwd << endl;
		}
	exit(0);
}
