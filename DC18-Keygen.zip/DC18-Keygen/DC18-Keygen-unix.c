/* Defcon-18 hardware badge ninja mode key generator
 * =================================================
 * This tool will brute force or generate a valid key
 * depending on options given to it. It borrows some
 * routines from DC18 firmware to validate when a key
 * is valid or not, additionally Samy Kamkar deserves
 * a mention as I borrowed some of his maths skills.
 *
 * -- prdelka
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <stdint.h>
#include <limits.h>

// enum used by the DC18 firmware for setting tumbler values
typedef enum {
	TOP = 0,
	MIDDLE = 1,
	BOTTOM = 2
} tumbler_state_type;

// DC18 tumbler array
tumbler_state_type gTumblers[15];

// These are globals to prevent problems with recursion
int tumbler[15], pin;
uint16_t a, b;

// DC18 firmware function to encode tumbler states into "24bit value"
unsigned int dc18_encode_tumblers(tumbler_state_type *tumblers) {
    unsigned int x = 0, j = 1;
    uint16_t i;
    for(i = 0; i < 15; i++) {
        x += tumblers[i] * j;
        j *= 3;
    }
    return x;
}

// Decode tumbler states, given a value "x" output the states of the tumblers
// The maths part here was adapted from Samy Kamkar's code (Thanks!).
unsigned int dc18_decode_tumblers(unsigned int x) {
	for(pin = 0; pin < 15;pin++){
		tumbler[pin] = 0;
	}
	pin = 0;
	while (x != 0) {
		tumbler[pin] = x % 3;
		x = x / 3;
		++pin;
	}
	for(pin = 0;pin < 15;pin++){
		printf("%d ",tumbler[pin]);
	}
	printf("\n");
	return x;
}

// Ninja validation routine from DC18 firmware w/ minor mod.
int dc18_ninja_validate(unsigned int val) {
    if(val > 14348907)	
	return 0;
    a = (uint16_t)(val & 0xfff);
    b = (uint16_t)(val >> 12);
    if((a ^ b) == 0x916) {
        return 1;
    }
    return 0;
}

// This function will generate a random tumbler state and attempt to validate it
// displaying any valid code it finds.
int dc18_random_crack(){
	int i,x,unlocked;
	unsigned int state;
	// loop generates a random tumbler state
	for(i = 0;i < 15;i++){
		x = (rand()%3);
		switch(x) {
			case 0:
				gTumblers[i] = TOP;
				break;
			case 1:
				gTumblers[i] = MIDDLE;
				break;
			case 2:
				gTumblers[i] = BOTTOM;
				break;
			default:
				 break;
		}
	}
	// encode the tumblers, attempt to validate, if successful display generated code. 
	state = dc18_encode_tumblers((tumbler_state_type*)&gTumblers);
	unlocked = dc18_ninja_validate(state);
	if(unlocked){
		printf("[ UNLOCK CODE: %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d\n[ Press enter for a new key",
				gTumblers[0],gTumblers[1],gTumblers[2],gTumblers[3],
				gTumblers[4],gTumblers[5],gTumblers[6],gTumblers[7],
				gTumblers[8],gTumblers[9],gTumblers[10],gTumblers[11],
				gTumblers[12],gTumblers[13],gTumblers[14],gTumblers[15]);
				getc(stdin);
		}
	return 0;
}

// This will attempt to test the value of x and output states
int dc18_testvalue(unsigned int x){
	if(dc18_ninja_validate(x)){
		printf("[ UNLOCK CODE: ");
		dc18_decode_tumblers(x);
	}
	else{
		printf("[ INVALID CODE: ");
		dc18_decode_tumblers(x);
	}
	return 0;
}

// Function to generate all valid unlock codes using tumbler decode routine.
int dc18_generate_all(){
	unsigned int x = 0;
	for(x = 0;x < 14348907;x++){
		if(dc18_ninja_validate(x)){
			printf("[ UNLOCK CODE: ");
			dc18_decode_tumblers(x);
		}
	}
	return 0;
}

// The main entry point for the generator
int main(int argc, char* argv[]) {
	int c,index, brute = 0;
	static struct option options[]={
		{"generate", 0, 0, 'g'},
		{"brute", 0, 0, 'b'},
		{"test", 1, 0, 't'},
		{"help", 0, 0,'h'}
	};
	printf("[ DC18 Ninja key generator v0.2 (*nix)\n");
	while(c!=-1) {
		c=getopt_long(argc,argv,"gbt:h",options,&index);	
		switch(c) {
			case 'g':
				dc18_generate_all();
				return 0;
				break;
			case 'b':
				brute = 1;
				break;
			case 't':
				dc18_testvalue(atoi(optarg));
				return 0;
				break;
			case 'h':
				printf("[ Usage. <%s>\n[\n", argv[0]);
				printf("[	--generate|-g		= generate all possible valid keys\n");
				printf("[	--test|-t		= test a specific key value\n");
				printf("[	--brute|-b		= crack random keys and output a valid one\n");
				printf("[	--help|-h		= usage and help instructions\n[\n");
				printf("[ To use the codes set the tumbler states to the following positions\n");
				printf("[ 0 = TOP  1 = MIDDLE  2 = BOTTOM\n");
				return 0;
				break;
			default:
				printf("[ You did not specify any options, try with --help\n");
				return 0;
				break;
		}
		while(brute){ // brute force
			dc18_random_crack();
		}
	}
}


