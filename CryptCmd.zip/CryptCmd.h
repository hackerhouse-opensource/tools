#include <iostream>
#include <winsock2.h>
#include <windows.h>
#include <openssl/rsa.h> 
#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/rand.h>

#define HOME "..\\certs\\"
#define CERTF HOME "server.pem"
#define KEYF HOME "server.pem"
#define CCERTF HOME "client.pem"
#define CKEYF HOME "client.pem"

#define BUFSIZE 65535

void bindserver(SOCKET is,struct sockaddr_in sa);
void connserver(SOCKET is,struct sockaddr_in sa);
void connclient(SOCKET is,struct sockaddr_in sa);
void bindclient(SOCKET is,struct sockaddr_in sa);

using namespace std;
