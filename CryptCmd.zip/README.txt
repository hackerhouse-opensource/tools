CryptCmd - encrypted network command shell
==========================================
[
[ "Everywhere you lookup, he got everybody shook up
[  running for cover, the big bad wolf motherfucker."
[
[ Starting client...
[ Connecting to 127.0.0.1 on port 8080
[ Connection established
[ SSL connection using DES-CBC3-SHA
Microsoft Windows XP [Version 5.1.2600]
(C) Copyright 1985-2001 Microsoft Corp

C:\WINDOWS\system32\certs\bin> 

* TODO

- SSL client side certificate (server must set flags)

- connectback timer delay (connect every x mins x hours etc)

- deployment package, executable + dlls are loaded into
  the system and deployed as a MS Service which is
  autostarted at boot time. Additional autostart routines
  such as direct registry or ctfmon/msmsg attacks.

- Support for HTTP proxy (when running behind or
  through a HTTP/SOCKS proxy) - get settings from IE
  or supply manual settings. (connect)

- file transfer support.

- eventvwr log cleaner (wipe eventvwr logs)

- secure file deletion (use sdelete src).

- Linux client.

 - prdelka
