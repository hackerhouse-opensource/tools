/* 
   Code to prevent WCRY ransomware on an unpatched host, registers
   the mutex used by the payload to prevent an infection from being 
   run on the host. Innoculates the host by registering the 
   same mutex. This wont stop your host being infected with the 
   worm and used to infect other hosts but it will stop the 
   ransomware component from being executed on a vulnerable host -
   stopping the payload.
   
   Compile with cl.exe /MT WCRYSLAP.cpp 
    -- Hacker Fantastic (www.myhackerhouse.com)
*/
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <tchar.h>
#include <Windows.h>
#include <Winuser.h>
#include <strsafe.h>

#pragma comment(lib, "user32")

int _tmain(int argc, _TCHAR* argv[])
{
	HWND hWnd = GetConsoleWindow();// comment for NT4
	HANDLE hMutexoneInstance = CreateMutex(NULL,TRUE,"Global\\MsWinZonesCacheCounterMutexA0");
	if(GetLastError()== ERROR_ALREADY_EXISTS){
		printf("This machine is infected with WCRY worm already\n");
		while(1){
			Sleep(10000);
		}
	}
	printf("WCRY Worm innoculation - minimize but do not close this task");
	ShowWindow(hWnd, SW_HIDE);
	while(1){
		Sleep(10000);
	}
	return 0;
}
